#!/bin/bash
# Build OpenSIMPLY

lazbuild -B OpenSIMPLY.lpk


