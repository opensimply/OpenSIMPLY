﻿OpenSIMPLY installation.
========================

*** Windows ***

1. Unpack the archive OpenSIMPLY.zip with the directory structure to the preferred location.
   It is recommended to use the name "OpenSIMPLY" for the unpacking directory.
   Do not forget to change the path to package file for other directory name.
 
2. Go to the subdirectory "bin" of "OpenSIMPLY" and launch the file "simply-setup.exe".
   Follow the instructions. 


Launch the projects with the learning examples from the subdirectory "tutorial".

Watch the learning videos at <youtube.opensimply.org>
 
Follow the news and information at <facebook.opensimply.org> 
 

*** Linux ***

1. On Ubuntu the package "Wine" is required to be installed before.
2. Intall OpenSIMPLY unsing "Wine".

Native Linux version of OpenSIMPLY is under way.  


Contents of OpenSIMPLY.zip
==========================

[OpenSIMPLY]           Root of zip file.
│
├─[bin]                Installation tools.
│ 
│
├─[doc]                Documentation in HTML and CHM formats.  
│ │
│ └─[html]  
│            
│			
├─[sources]            The sources of OpenSIMPLY.
│ │  
│ └─[lazarus]          Lazarus package for OpenSIMPLY.   
│
│			
└─[tutorial]              
  │ 
  ├─[delphi]           Tutorial for Delphi users. 
  │	  
  ├─[lazarus]          Tutorial for Lazarus users. 
  │
  └─[pas]              Tutorial sources.


