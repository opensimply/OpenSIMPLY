#!/bin/bash
# Build OpenSIMPLY

lazbuild -B ./opensimply.lpk

lazbuild -B ./opensimply_debug.lpk


